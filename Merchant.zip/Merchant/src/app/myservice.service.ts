import { Injectable } from '@angular/core';
import{HttpClient}from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';


@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  url: string = "http://localhost:9123/merchant";
  products : number;
  constructor(private http: HttpClient) {
  }
  private handleError(error: any): Promise<any> {
    return Promise.reject(error.error || error);
  }
  
  
 
//  addMerchant(m:Merchant){
//   this.merchants.push(m);
  
// }

    

// fetched:boolean=false;
// fetchMerchants(){
// this.http.get('./assets/merchant.json')
//  .subscribe(
// data=>{
// if(!this.fetched)
//  {
// this.convert(data);
// this.fetched=true;
//  }
//  }
//  );
// }

//   getMerchants():Merchant[]{
    
  
// return this.merchants;
// }
// convert(data1:any){
// for(let o of data1)
//  {
// let m=new Merchant(o.merchantId,o.merchantAnswer,o.merchantCompanyName,o.merchantContactNo,o.merchantDiscount,o.merchantGSTNo,o.merchantName,o.merchantPassword,o.merchantQuestion,o.merchantStatus);
// this.merchants.push(m);
//  }

addMerchant(merchant): Promise<any> {
  return this.http.post(this.url + '/addMerchant', merchant)
    .toPromise()
    .then(response => response)
    .catch(this.handleError);
    
}
addProducts(product): Promise<any> {
  return this.http.post(this.url + '/addProduct/', product)
    .toPromise()
    .then(response => response)
    .catch(this.handleError);
}

 getproductById(merchantId: number):  Observable<Product> {
   return this.http.get<Product>(this.url + '/fetchProduct/' + merchantId)
    
}
   

}
export class Merchant{
  merchantId:number;
  merchantCompanyName:string;
  merchantContactNo:string;
  merchantDiscount:number;
  emailid:string;
  merchantName:string;
  merchantPassword:string;
  aadharNumber:string;


    
        constructor(  merchantId:number,merchantCompanyName:string,merchantContactNo:string,merchantDiscount:number,emailid:string,merchantName:string,merchantPassword:string,aadharNumber:string)
        {
          this.merchantId=merchantId;
          this.merchantCompanyName=merchantCompanyName;
          this.merchantContactNo=merchantContactNo;
          this.merchantDiscount=merchantDiscount;
          this.merchantName=merchantName;
          this.merchantPassword=merchantPassword;
          this.emailid=emailid;
          this.aadharNumber=aadharNumber;
        }
        
      }
      export class Product{
        merchantId:number;
        productId:number;
        productAvailability:number;
        productDescription:string;
        productName:string;
        productPrice:number;
        productType:string;
        constructor(merchantId:number,productId:number,productAvailability:number,productDescription:string,productName:string,productPrice:number,productType:string)
        {
         this.merchantId=merchantId;
          this.productId=productId;
          this.productAvailability=productAvailability;
          this.productDescription=productDescription;
          this.productName=productName;
          this.productPrice=productPrice;
          this.productType=productType;
        }


      }