import { Component, OnInit } from '@angular/core';
import{MyserviceService,Product,Merchant} from '../myservice.service';
@Component({
  selector: 'app-next',
  templateUrl: './next.component.html',
  styleUrls: ['./next.component.css']
})
export class NextComponent implements OnInit {

  service:MyserviceService;

products: Product[] = [];
  constructor(service:MyserviceService) {
    this.service=service;
    
    }
    
    merchants:Merchant[]=[]//creating employees object for Employee Array 
    ngOnInit() {
      
     
    }

    getAllProducts(merchantId) {

     return this.service.getproductById(merchantId).subscribe(data => {
      
        this.service.products=merchantId;
        
      
    });
  }
}