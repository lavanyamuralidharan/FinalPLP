import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MerchantLoginComponent } from './merchant-login/merchant-login.component';
import { ApproutingModule } from './approuting.module';
import { RegisterComponent } from './register/register.component';
import { NextComponent } from './next/next.component';
import { AddproductComponent } from './addproduct/addproduct.component';

import { MyserviceService } from './myservice.service';

import{FormsModule, ReactiveFormsModule} from '@angular/forms'
import { HttpClientModule, HttpClient } from '../../node_modules/@angular/common/http';
import { LoginComponent } from './login/login.component';
                  


@NgModule({
  declarations: [
  
    AppComponent,
    MerchantLoginComponent,
    RegisterComponent,
    NextComponent,
    AddproductComponent,
   
    LoginComponent,
    
    
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    ApproutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [HttpClient,MyserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
