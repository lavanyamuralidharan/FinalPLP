import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Merchant } from './myservice.service';
import { Router } from '@angular/router';
import { Observable } from '../../node_modules/rxjs';
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  user : number;

  merchants:Merchant[]=[];
  flagMerchant:boolean=false;
  constructor(private http: HttpClient, private router:Router) { 
    
    // this.fetchMerchant();
    // console.log(this.merchants);
  }
//   fetchMerchant() {
   
//     var merchant = this.http.get('http://localhost:9123/merchant/login/'+this.user+'/'+this.pass);
//     merchant.subscribe((data) => {
//       this.convertMerchant(data);
//     })
//   }
//     convertMerchant(data: any) {
//       for (let o of data) {
//         let e = new Merchant(o.merchantId,o.merchantCompanyName,o.merchantContactNo,o.merchantDiscount,o.emailid,o.merchantName,o.merchantPassword,o.aadharnumber);
//         this.merchants.push(e);
//       }
//     }
//     loginAccount(data: any):boolean {
//       for (let m of this.merchants) {
//         if (m.merchantId == data.merchantId && m.merchantPassword == data.merchantPassword) {
//           alert("You are Merchant :-)")
//           this.flagMerchant=true;
//           this.router.navigate(['login']);
//           return true;
// }
//       }
    
  loginAccount(user : number,pass : string) : Observable<boolean>
{
  return this.http.get<boolean>('http://localhost:9123/merchant/login/'+user+'/'+pass);
}
}