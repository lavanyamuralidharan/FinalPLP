import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes}from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { MerchantLoginComponent } from './merchant-login/merchant-login.component';
import { NextComponent } from './next/next.component';
import { AddproductComponent } from './addproduct/addproduct.component';

import { LoginComponent } from './login/login.component';
const routes:Routes=[
{
  path:'register',
  component:RegisterComponent
},
{
  path:'login',
  component:MerchantLoginComponent
},

{
  path:'next',
  component:NextComponent
},
{
  path:'addproduct',
  component:AddproductComponent
},


{
path:'login-in',
component:LoginComponent
}
];
@NgModule({
  imports:[RouterModule.forRoot(routes)],
  exports:[RouterModule]
    
})
export class ApproutingModule { }
