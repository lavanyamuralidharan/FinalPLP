import { Component, OnInit } from '@angular/core';
import{Router}from '@angular/router';
import { LoginService } from '../login.service';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  userId : number;
  userPassword = ''
 // status : boolean;
 
  constructor(private service:LoginService, private router:Router,private auth:AuthenticationService) { 
 
 }
 ngOnInit() {
}
// checkLogin(data: any) {
//   var encryptmerchantId = (merchantId): number => {
//     var genereatedId = parseInt(merchantId) - 500000;
//     return genereatedId;
//   }
//   if(this.login.loginAccount(data)){
//     let encryptMerchantId = encryptmerchantId(data.merchantId);
//     this.auth.sendToken(encryptMerchantId.toString());
//   }
// }

login()
{
  return this.service.loginAccount(this.userId,this.userPassword).subscribe(data => {
      if(data==true)
      {
        this.service.user=this.userId;
        this.router.navigateByUrl('addproduct');
        alert("Login successfully ");
      }
      else{
        alert("please enter correct credentials")
      }

  }
  
  )
}
}