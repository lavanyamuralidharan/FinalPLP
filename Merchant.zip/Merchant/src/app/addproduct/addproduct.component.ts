import { Component, OnInit } from '@angular/core';
import{Router}from '@angular/router';
import {Product,MyserviceService} from '../myservice.service';

@Component({
  
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
  
  router:Router;
  createdFlag:boolean=false;
  service:MyserviceService;
  
  constructor(service:MyserviceService, router:Router) {this.service=service; 
    

 this.router=router
 }

  ngOnInit() {
  }
  addProducts(data) {
    let createdProduct = new Product(data.merchant_Id,data.merchant_Id,data.productAvailability,data.productDescription,data.productName,data.productPrice,data.productType);
    this.service.addProducts(createdProduct).then(response => {
     
        alert("Product added successfully");
        this.router.navigateByUrl('next');
      }
    
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
          console.log(err.error);
        }
      });
  }
  }
  
