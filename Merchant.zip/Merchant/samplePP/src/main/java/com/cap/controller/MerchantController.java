package com.cap.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.entities.Merchant;
import com.cap.entities.Product;
import com.cap.service.MerchantService;
@RestController
@CrossOrigin(origins ="*")
@RequestMapping("/merchant")
public class MerchantController {
	
	@Autowired
	MerchantService service;
	
	@PostMapping("/addMerchant")
	public Merchant addMerchant(@RequestBody Merchant merchant) {
	return	service.addMerchant(merchant);
	}
	@GetMapping("/login/{merchant_Id}/{merchantPassword}")
	public Boolean findByMerchantEmail(@PathVariable int merchant_Id,@PathVariable String merchantPassword) {
		return service.findByCustomerEmail(merchant_Id, merchantPassword);
	}
	@PostMapping("/addProduct")
	public Product addProduct(@RequestBody Product product) {
		return	service.addProduct(product);
		
	}
	
	@GetMapping("/fetchProduct/{merchantId}")
    public Optional<Product> fetchProduct(@PathVariable int merchantId) {
    return    service.fetchProduct(merchantId);
    }
   
	

}
