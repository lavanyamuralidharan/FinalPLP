package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_products4")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "product_seq_gen")
	@SequenceGenerator(name = "product_seq_gen", initialValue = 1000, sequenceName = "product_seq")
	private long productId;

	@Column(length = 20)
	private String productType;



	// @ForeignKey(name="merchanEmail")
	
	
	@Column(length = 10)
	private String productName;
	@Column(length = 20)
	private double productPrice;
	@Column(length = 10)
	private String productDescription;
	@Column(length = 10)
	private int productAvailability;

	//@ManyToOne(fetch = FetchType.LAZY)
	//@JoinTable( name = "Answer", joinColumns = @JoinColumn ( name = "question_id"),
	//@JoinColumn(name = "email")
	//@OneToMany(fetch = FetchType.LAZY)
	//@JoinTable(name="capstore_merchants", joinColumns=@JoinColumn(name="email"))
	
	@Column
	
	private int merchantId;
	
	

	

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public int getProductAvailability() {
		return productAvailability;
	}

	public void setProductAvailability(int productAvailability) {
		this.productAvailability = productAvailability;
	}

	
	public Product(long productId, String productType, String productName, double productPrice,
			String productDescription, int productAvailability, int merchantId) {
		super();
		this.productId = productId;
		this.productType = productType;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productDescription = productDescription;
		this.productAvailability = productAvailability;
		this.merchantId = merchantId;
	}

	public Product() {
		// TODO Auto-generated constructor stub
	}
}
