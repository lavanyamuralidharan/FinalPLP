package com.cap.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.MerchantRepo;
import com.cap.dao.ProductRepo;

import com.cap.entities.Merchant;
import com.cap.entities.Product;
import com.cap.exception.CapStore;


@Service
public class MerchantServiceImpl implements MerchantService{
	@Autowired
	MerchantRepo repo;
	@Autowired
	ProductRepo repo1;
	@Autowired
Optional<Merchant> merchant;
	@Override
	public Merchant addMerchant(Merchant merchant) {
		repo.save(merchant);
		return merchant;
	}

	@Override
	public Boolean findByCustomerEmail(int merchant_Id, String merchantPassword)  {
		merchant=repo.findById(merchant_Id);
		if(merchant.get().getMerchant_Id()==merchant_Id && merchant.get().getMerchantPassword().equals(merchantPassword)){ 
			System.out.println("Login Successfully");
			
			return true;
		}
		else
		{
			return false;
		}
		
	}

	@Override
	public Product addProduct(Product product) {
		
		repo1.save(product);
	
		return product;
	}

	@Override
	public Optional<Product> fetchProduct(int merchantId) {
		Optional<Product> product=repo1.fetchProduct(merchantId);
		
		return product;
	}



	
	}

	
	

	



