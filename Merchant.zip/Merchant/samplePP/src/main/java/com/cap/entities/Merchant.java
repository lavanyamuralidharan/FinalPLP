package com.cap.entities;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="merch5")
public class Merchant  {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "merchant_seq_gen")
	@SequenceGenerator(name = "merchant_seq_gen", initialValue = 1000, sequenceName = "merchant_seq_gen")
	@Column(length=25)
	private int merchant_Id;
	@Column(length=25)
	private String merchantName;
	@Column(length=25)
	private String emailid;
	@Column(length=15)
    private String merchantPassword;
	
	
	
	@Column(length=15)
	private String merchantContactNo;
	@Column(length=15)
	private String merchantCompanyName;
	@Column(length=15)
	private int merchantDiscount;
	@Column(length=20)
	private String aadharNumber;
	@Column(length=10)
	private String status="Inactive";
	
	public Merchant() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getMerchant_Id() {
		return merchant_Id;
	}

	public void setMerchant_Id(int merchant_Id) {
		this.merchant_Id = merchant_Id;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getMerchantPassword() {
		return merchantPassword;
	}

	public void setMerchantPassword(String merchantPassword) {
		this.merchantPassword = merchantPassword;
	}

	public String getMerchantContactNo() {
		return merchantContactNo;
	}

	public void setMerchantContactNo(String merchantContactNo) {
		this.merchantContactNo = merchantContactNo;
	}

	public String getMerchantCompanyName() {
		return merchantCompanyName;
	}

	public void setMerchantCompanyName(String merchantCompanyName) {
		this.merchantCompanyName = merchantCompanyName;
	}

	public int getMerchantDiscount() {
		return merchantDiscount;
	}

	public void setMerchantDiscount(int merchantDiscount) {
		this.merchantDiscount = merchantDiscount;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	

	public Merchant(int merchant_Id, String merchantName, String emailid, String merchantPassword,
			String merchantContactNo, String merchantCompanyName, int merchantDiscount, String aadharNumber,
			String status) {
		super();
		this.merchant_Id = merchant_Id;
		this.merchantName = merchantName;
		this.emailid = emailid;
		this.merchantPassword = merchantPassword;
		this.merchantContactNo = merchantContactNo;
		this.merchantCompanyName = merchantCompanyName;
		this.merchantDiscount = merchantDiscount;
		this.aadharNumber = aadharNumber;
		this.status = status;
	}

	@Override
	public String toString() {
		return "Merchant [merchant_Id=" + merchant_Id + ", merchantName=" + merchantName + ", emailid=" + emailid
				+ ", merchantPassword=" + merchantPassword + ", merchantContactNo=" + merchantContactNo
				+ ", merchantCompanyName=" + merchantCompanyName + ", merchantDiscount=" + merchantDiscount
				+ ", aadharNumber=" + aadharNumber + ", status=" + status + "]";
	}

	
	
	
}