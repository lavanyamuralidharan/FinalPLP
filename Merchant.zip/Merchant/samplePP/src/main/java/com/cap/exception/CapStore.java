package com.cap.exception;

public class CapStore extends RuntimeException{
	

	public CapStore(String message) {
		super(message);
	}
}
