package com.cap.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;


import com.cap.entities.Merchant;
import com.cap.entities.Product;
import com.cap.exception.CapStore;


@Service

public interface MerchantService  {
	public Merchant addMerchant(Merchant merchant);

	public Product addProduct(Product product);

	public Boolean findByCustomerEmail(int merchant_Id, String merchantPassword) ;

	public Optional<Product> fetchProduct(int merchantId);

	
	
	

	

}
