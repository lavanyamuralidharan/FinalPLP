package com.cap.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cap.entities.Product;

@Repository
public interface ProductRepo extends JpaRepository<Product,Long> {
	
	
	@Query("from  Product where merchantId=?1")
	/*@Query(value="select * from capstore_merchants where merchant_status like 'inactive'",nativeQuery = true)*/
	public Optional<Product> fetchProduct(int merchantId);

}
